from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
sys.path.insert(0, str(SRC_DIR))

from compound_control.config import load_config
from compound_control.exchange.binance.client import BinanceUsdMReadOnlyClient
from compound_control.repository.sqlite import SqliteRepository


def main() -> None:
    config = load_config(PROJECT_ROOT / "config/settings.yaml")
    client = BinanceUsdMReadOnlyClient.from_env()
    account = client.account()

    trading_equity = float(account["totalMarginBalance"])
    available = float(account["availableBalance"])
    unrealized = float(account["totalUnrealizedProfit"])
    reporting_equity = trading_equity * float(config.currency["usdt_to_idr"])

    repository = SqliteRepository(PROJECT_ROOT / "data/compound_control.db")
    repository.save_equity_snapshot(
        captured_at=datetime.now(timezone.utc).isoformat(),
        trading_equity=trading_equity,
        reporting_equity=reporting_equity,
        available_balance=available,
        unrealized_pnl=unrealized,
        source="BINANCE_USDM",
    )

    print(f"Trading equity : {trading_equity:,.2f} USDT")
    print(f"Reporting eq.  : Rp{reporting_equity:,.0f}")
    print(f"Available      : {available:,.2f} USDT")
    print(f"Unrealized PnL : {unrealized:,.2f} USDT")


if __name__ == "__main__":
    main()
