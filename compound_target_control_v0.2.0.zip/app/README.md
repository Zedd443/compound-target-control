# Compound Target Control v0.2 — Streamlit Cloud Ready

Mobile-friendly target/risk planner for Binance USD-M Futures.

## What changed in v0.2

- Streamlit Cloud `st.secrets` support.
- Local `.env` remains supported as fallback.
- Binance Futures equity is read live when the app runs.
- Start equity is captured from live Binance equity when `Start Plan` is pressed.
- Target equity is entered from the UI.
- Horizon is entered from the UI in months.
- Current equity is always live Binance equity.
- Plan state is stored in non-sensitive URL query parameters, so the plan can survive Streamlit sleep/restart without an external database.
- Mobile-friendly tabs: Mission Control, Trade Planner, Plan.

## Streamlit Cloud deployment

1. Create a **private GitHub repository**.
2. Upload the contents of this folder to the repository root.
3. Open Streamlit Community Cloud and create a new app from the repo.
4. Main file path:

```text
src/compound_control/dashboard_app.py
```

5. In Streamlit **App settings → Secrets**, paste:

```toml
BINANCE_API_KEY = "YOUR_READ_ONLY_KEY"
BINANCE_API_SECRET = "YOUR_SECRET"
BINANCE_FUTURES_BASE_URL = "https://fapi.binance.com"
```

Do **not** upload `.env` to GitHub.

## Binance API permissions

Use a dedicated API key for this dashboard.

- Withdrawal: OFF
- Trading/order permission: not required by this project
- The code exposes no order-placement method

## First use

When the app opens:

1. It reads current Binance Futures equity.
2. Enter your target equity in IDR.
3. Enter the horizon in months.
4. Press **Start Plan**.
5. The current live balance becomes the immutable starting balance for that plan.
6. Bookmark the resulting URL.

The URL contains only:

- plan start equity,
- plan target equity,
- start date,
- target date.

It does **not** contain Binance API credentials.

## Important limitation

The dashboard currently reads standard Binance USD-M Futures account equity. If Binance Copy Trading uses a separate wallet that is not exposed through the same account endpoint, the displayed amount may differ. Compare the app equity with the value shown in Binance before relying on it as the plan source.

## Local development

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run src/compound_control/dashboard_app.py
```

Linux/macOS:

```bash
source .venv/bin/activate
pip install -r requirements.txt
streamlit run src/compound_control/dashboard_app.py
```

For local development, copy `.env.example` to `.env` and fill the credentials.

## Tests

```bash
pytest -q
```
