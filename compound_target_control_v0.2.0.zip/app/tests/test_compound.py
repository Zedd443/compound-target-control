from datetime import date
import math

from compound_control.domain.models import Goal
from compound_control.goals.compound import baseline_equity, build_goal_snapshot


def test_baseline_starts_and_ends_at_goal_boundaries():
    goal = Goal(10_000_000, 10_000_000_000, date(2026, 1, 1), date(2028, 1, 1))
    assert baseline_equity(goal, goal.start_date) == goal.start_equity
    assert math.isclose(baseline_equity(goal, goal.target_date), goal.target_equity, rel_tol=1e-9)


def test_snapshot_recalculates_required_return_from_current_equity():
    goal = Goal(10_000_000, 10_000_000_000, date(2026, 1, 1), date(2028, 1, 1))
    snapshot = build_goal_snapshot(goal, 100_000_000, date(2027, 1, 1))
    assert snapshot.days_remaining > 0
    assert snapshot.current_monthly_return > 0
    assert snapshot.progress_pct == 0.01
