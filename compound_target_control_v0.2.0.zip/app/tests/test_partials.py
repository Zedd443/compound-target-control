from compound_control.domain.models import PartialExit
from compound_control.execution.partials import calculate_partial_plan


def test_weighted_partial_r_and_costs():
    exits = [PartialExit(0.25, 1.0), PartialExit(0.25, 2.0), PartialExit(0.25, 3.0), PartialExit(0.25, None)]
    result = calculate_partial_plan(initial_risk=100, exits=exits, trailing_r_multiple=4.0, estimated_cost=10)
    assert result.gross_r == 2.5
    assert result.net_r == 2.4
