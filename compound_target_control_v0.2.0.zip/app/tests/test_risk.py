from compound_control.domain.models import RiskContext, TargetStatus, VolatilityRegime
from compound_control.risk.controller import RiskController

CONFIG = {
    "base_risk_pct": 0.004,
    "absolute_min_risk_pct": 0.0015,
    "absolute_max_risk_pct": 0.006,
    "target_multiplier": {"far_ahead": 0.60, "ahead": 0.80, "on_track": 1.00, "slightly_behind": 1.10, "far_behind": 1.25},
    "drawdown_multiplier": {"dd_0_5": 1.00, "dd_5_10": 0.80, "dd_10_15": 0.60, "dd_15_plus": 0.40},
    "volatility_multiplier": {"low": 1.00, "normal": 1.00, "high": 0.85, "extreme": 0.70},
    "equity_tiers": [{"max_equity": None, "multiplier": 1.0}],
    "max_open_risk_pct": 0.015,
    "preservation_drawdown_pct": 0.15,
}


def test_drawdown_can_override_target_pressure():
    decision = RiskController(CONFIG).decide(RiskContext(100_000_000, 0.12, TargetStatus.FAR_BEHIND, VolatilityRegime.NORMAL, 0))
    assert abs(decision.effective_risk_pct - 0.003) < 1e-12


def test_open_risk_caps_new_trade_risk():
    decision = RiskController(CONFIG).decide(RiskContext(100_000_000, 0, TargetStatus.ON_TRACK, VolatilityRegime.NORMAL, 0.014))
    assert abs(decision.effective_risk_pct - 0.001) < 1e-12
    assert decision.capped_by_open_risk
