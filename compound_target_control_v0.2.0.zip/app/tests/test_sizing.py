from compound_control.domain.models import TradeSetup
from compound_control.sizing.position import calculate_position_size


def test_position_sizing_accounts_for_estimated_costs():
    result = calculate_position_size(
        trading_equity=10_000,
        effective_risk_pct=0.004,
        setup=TradeSetup("BTCUSDT", "LONG", 100_000, 98_000, 5),
        execution_config={"estimated_round_trip_fee_pct": 0.0008, "estimated_slippage_pct": 0.0004, "max_notional_to_equity": 3.0},
    )
    assert result.risk_budget == 40
    assert result.stop_distance_pct == 0.02
    assert result.estimated_loss_at_stop <= 40.0000001
    assert result.required_margin > 0


def test_notional_cap_prevents_extreme_tight_stop_position():
    result = calculate_position_size(
        trading_equity=10_000,
        effective_risk_pct=0.004,
        setup=TradeSetup("BTCUSDT", "LONG", 100_000, 99_990, 10),
        execution_config={"estimated_round_trip_fee_pct": 0.0008, "estimated_slippage_pct": 0.0004, "max_notional_to_equity": 1.0},
    )
    assert result.recommended_notional == 10_000
    assert result.capped_by_notional_limit
