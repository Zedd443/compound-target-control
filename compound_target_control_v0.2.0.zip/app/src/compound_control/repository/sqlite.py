from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


SCHEMA = """
CREATE TABLE IF NOT EXISTS equity_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    captured_at TEXT NOT NULL,
    trading_equity REAL NOT NULL,
    reporting_equity REAL NOT NULL,
    available_balance REAL,
    unrealized_pnl REAL,
    source TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trade_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    entry REAL NOT NULL,
    stop_loss REAL NOT NULL,
    leverage REAL NOT NULL,
    equity_at_plan REAL NOT NULL,
    risk_pct REAL NOT NULL,
    risk_budget REAL NOT NULL,
    notional REAL NOT NULL,
    estimated_loss REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'PLANNED'
);

CREATE TABLE IF NOT EXISTS trade_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_plan_id INTEGER,
    closed_at TEXT NOT NULL,
    gross_pnl REAL NOT NULL,
    commission REAL NOT NULL DEFAULT 0,
    funding REAL NOT NULL DEFAULT 0,
    slippage REAL NOT NULL DEFAULT 0,
    net_pnl REAL NOT NULL,
    initial_risk REAL NOT NULL,
    net_r REAL NOT NULL,
    FOREIGN KEY (trade_plan_id) REFERENCES trade_plans(id)
);
"""


class SqliteRepository:
    def __init__(self, path: str | Path = "data/compound_control.db") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def initialize(self) -> None:
        with self.connection() as connection:
            connection.executescript(SCHEMA)

    def save_equity_snapshot(self, *, captured_at: str, trading_equity: float, reporting_equity: float, available_balance: float | None, unrealized_pnl: float | None, source: str) -> int:
        with self.connection() as connection:
            cursor = connection.execute(
                """
                INSERT INTO equity_snapshots (
                    captured_at, trading_equity, reporting_equity,
                    available_balance, unrealized_pnl, source
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (captured_at, trading_equity, reporting_equity, available_balance, unrealized_pnl, source),
            )
            return int(cursor.lastrowid)
