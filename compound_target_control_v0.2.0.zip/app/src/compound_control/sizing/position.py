from __future__ import annotations

from typing import Any

from compound_control.domain.models import PositionSize, TradeSetup


def calculate_position_size(
    *,
    trading_equity: float,
    effective_risk_pct: float,
    setup: TradeSetup,
    execution_config: dict[str, Any],
) -> PositionSize:
    if trading_equity <= 0:
        raise ValueError("trading_equity must be positive")
    if effective_risk_pct < 0:
        raise ValueError("effective_risk_pct cannot be negative")
    if setup.entry <= 0 or setup.stop_loss <= 0:
        raise ValueError("entry and stop_loss must be positive")
    if setup.leverage <= 0:
        raise ValueError("leverage must be positive")
    if setup.entry == setup.stop_loss:
        raise ValueError("entry and stop_loss cannot be equal")

    stop_distance_pct = abs(setup.entry - setup.stop_loss) / setup.entry
    risk_budget = trading_equity * effective_risk_pct

    fee_pct = float(execution_config["estimated_round_trip_fee_pct"])
    slippage_pct = float(execution_config["estimated_slippage_pct"])
    cost_rate = fee_pct + slippage_pct

    denominator = stop_distance_pct + cost_rate
    raw_notional = risk_budget / denominator if denominator > 0 else 0.0

    max_notional = trading_equity * float(execution_config["max_notional_to_equity"])
    recommended = min(raw_notional, max_notional)
    capped = recommended < raw_notional

    estimated_cost = recommended * cost_rate
    price_loss = recommended * stop_distance_pct
    estimated_loss = price_loss + estimated_cost
    margin = recommended / setup.leverage
    actual_risk_pct = estimated_loss / trading_equity

    return PositionSize(
        risk_budget=risk_budget,
        stop_distance_pct=stop_distance_pct,
        raw_notional=raw_notional,
        recommended_notional=recommended,
        required_margin=margin,
        estimated_cost=estimated_cost,
        estimated_loss_at_stop=estimated_loss,
        account_risk_pct=actual_risk_pct,
        capped_by_notional_limit=capped,
    )
