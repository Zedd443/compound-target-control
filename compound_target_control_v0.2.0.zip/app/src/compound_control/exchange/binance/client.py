from __future__ import annotations

import hashlib
import hmac
import os
import time
from dataclasses import dataclass
from typing import Any, Mapping
from urllib.parse import urlencode

import requests
from dotenv import load_dotenv


class BinanceApiError(RuntimeError):
    pass


@dataclass(frozen=True)
class BinanceCredentials:
    api_key: str
    api_secret: str


class BinanceUsdMReadOnlyClient:
    """Minimal read-only Binance USD-M Futures REST client.

    The client intentionally exposes no order placement, cancellation,
    withdrawal, or transfer methods.
    """

    def __init__(
        self,
        credentials: BinanceCredentials,
        base_url: str = "https://fapi.binance.com",
        timeout: float = 10.0,
    ) -> None:
        self._credentials = credentials
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({"X-MBX-APIKEY": credentials.api_key})

    @classmethod
    def from_sources(
        cls,
        secrets: Mapping[str, Any] | None = None,
    ) -> "BinanceUsdMReadOnlyClient":
        """Load credentials from Streamlit secrets first, then `.env`.

        Streamlit Cloud passes `st.secrets` here. Local development can omit
        the argument and rely on `.env`.
        """
        load_dotenv()
        secrets = secrets or {}

        api_key = str(
            secrets.get("BINANCE_API_KEY") or os.getenv("BINANCE_API_KEY", "")
        ).strip()
        api_secret = str(
            secrets.get("BINANCE_API_SECRET")
            or os.getenv("BINANCE_API_SECRET", "")
        ).strip()
        base_url = str(
            secrets.get("BINANCE_FUTURES_BASE_URL")
            or os.getenv("BINANCE_FUTURES_BASE_URL", "https://fapi.binance.com")
        ).strip()

        if not api_key or not api_secret:
            raise BinanceApiError(
                "Binance credentials not found. Add them to Streamlit Secrets "
                "or to a local .env file."
            )

        return cls(
            BinanceCredentials(api_key=api_key, api_secret=api_secret),
            base_url=base_url,
        )

    @classmethod
    def from_env(cls) -> "BinanceUsdMReadOnlyClient":
        return cls.from_sources()

    def account(self) -> dict[str, Any]:
        return self._signed_get("/fapi/v3/account")

    def balances(self) -> list[dict[str, Any]]:
        return self._signed_get("/fapi/v3/balance")

    def positions(self) -> list[dict[str, Any]]:
        return self._signed_get("/fapi/v3/positionRisk")

    def income_history(
        self,
        *,
        start_time_ms: int | None = None,
        end_time_ms: int | None = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if start_time_ms is not None:
            params["startTime"] = start_time_ms
        if end_time_ms is not None:
            params["endTime"] = end_time_ms
        return self._signed_get("/fapi/v1/income", params)

    def user_trades(
        self,
        symbol: str,
        *,
        start_time_ms: int | None = None,
        end_time_ms: int | None = None,
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"symbol": symbol.upper(), "limit": limit}
        if start_time_ms is not None:
            params["startTime"] = start_time_ms
        if end_time_ms is not None:
            params["endTime"] = end_time_ms
        return self._signed_get("/fapi/v1/userTrades", params)

    def exchange_info(self) -> dict[str, Any]:
        return self._public_get("/fapi/v1/exchangeInfo")

    def _public_get(self, path: str) -> Any:
        response = self._session.get(
            f"{self._base_url}{path}", timeout=self._timeout
        )
        return self._decode(response)

    def _signed_get(
        self, path: str, params: dict[str, Any] | None = None
    ) -> Any:
        payload = dict(params or {})
        payload["timestamp"] = int(time.time() * 1000)
        payload["recvWindow"] = 5000

        query = urlencode(payload)
        signature = hmac.new(
            self._credentials.api_secret.encode(),
            query.encode(),
            hashlib.sha256,
        ).hexdigest()
        url = f"{self._base_url}{path}?{query}&signature={signature}"

        response = self._session.get(url, timeout=self._timeout)
        return self._decode(response)

    @staticmethod
    def _decode(response: requests.Response) -> Any:
        try:
            payload = response.json()
        except ValueError as exc:
            raise BinanceApiError(
                f"Binance returned non-JSON response: {response.status_code}"
            ) from exc

        if not response.ok:
            message = (
                payload.get("msg", "Unknown Binance API error")
                if isinstance(payload, dict)
                else str(payload)
            )
            raise BinanceApiError(
                f"Binance API error {response.status_code}: {message}"
            )
        return payload
