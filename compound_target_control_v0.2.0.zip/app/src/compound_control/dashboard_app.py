from __future__ import annotations

from datetime import date, datetime
from pathlib import Path
import math
import sys

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from compound_control.config import load_config
from compound_control.domain.models import Goal, TradeSetup, VolatilityRegime
from compound_control.exchange.binance.client import (
    BinanceApiError,
    BinanceUsdMReadOnlyClient,
)
from compound_control.goals.compound import baseline_equity, build_goal_snapshot
from compound_control.risk.controller import RiskController
from compound_control.services.planner import PlanningService


PLAN_KEYS = {
    "start_equity": "ps",
    "target_equity": "pt",
    "start_date": "pd0",
    "target_date": "pd1",
}


def money(value: float, currency: str) -> str:
    if currency == "IDR":
        return f"Rp{value:,.0f}"
    return f"{value:,.2f} {currency}"


@st.cache_data
def load_settings():
    return load_config(PROJECT_ROOT / "config/settings.yaml")


def streamlit_secrets() -> dict[str, str]:
    try:
        return {key: str(value) for key, value in st.secrets.items()}
    except Exception:
        return {}


@st.cache_resource(show_spinner=False)
def binance_client() -> BinanceUsdMReadOnlyClient:
    return BinanceUsdMReadOnlyClient.from_sources(streamlit_secrets())


def read_binance_equity() -> tuple[float, float, float]:
    account = binance_client().account()
    equity = float(account["totalMarginBalance"])
    available = float(account["availableBalance"])
    unrealized = float(account["totalUnrealizedProfit"])
    return equity, available, unrealized


def query_float(key: str) -> float | None:
    raw = st.query_params.get(key)
    if raw is None:
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


def query_date(key: str) -> date | None:
    raw = st.query_params.get(key)
    if not raw:
        return None
    try:
        return date.fromisoformat(str(raw))
    except ValueError:
        return None


def load_plan_from_url() -> Goal | None:
    start_equity = query_float(PLAN_KEYS["start_equity"])
    target_equity = query_float(PLAN_KEYS["target_equity"])
    start_date = query_date(PLAN_KEYS["start_date"])
    target_date = query_date(PLAN_KEYS["target_date"])

    if not all((start_equity, target_equity, start_date, target_date)):
        return None
    if target_equity <= 0 or start_equity <= 0 or target_date <= start_date:
        return None

    return Goal(
        start_equity=start_equity,
        target_equity=target_equity,
        start_date=start_date,
        target_date=target_date,
        reporting_currency="IDR",
    )


def save_plan_to_url(goal: Goal) -> None:
    st.query_params[PLAN_KEYS["start_equity"]] = f"{goal.start_equity:.8f}"
    st.query_params[PLAN_KEYS["target_equity"]] = f"{goal.target_equity:.8f}"
    st.query_params[PLAN_KEYS["start_date"]] = goal.start_date.isoformat()
    st.query_params[PLAN_KEYS["target_date"]] = goal.target_date.isoformat()


def clear_plan_from_url() -> None:
    for key in PLAN_KEYS.values():
        if key in st.query_params:
            del st.query_params[key]


def add_months(start: date, months: int) -> date:
    month_index = start.month - 1 + months
    year = start.year + month_index // 12
    month = month_index % 12 + 1
    month_lengths = [31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28,
                     31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    day = min(start.day, month_lengths[month - 1])
    return date(year, month, day)


def build_curve(goal: Goal, current_equity: float, as_of: date) -> pd.DataFrame:
    total_days = (goal.target_date - goal.start_date).days
    step = max(total_days // 120, 1)
    dates = [
        goal.start_date + pd.Timedelta(days=i)
        for i in range(0, total_days + 1, step)
    ]
    if dates[-1].date() != goal.target_date:
        dates.append(pd.Timestamp(goal.target_date))

    remaining_days = max((goal.target_date - as_of).days, 1)
    rows = []
    for timestamp in dates:
        current_date = timestamp.date()
        original = baseline_equity(goal, current_date)
        dynamic = None
        if current_date >= as_of:
            elapsed = (current_date - as_of).days
            remaining_multiple = goal.target_equity / current_equity
            dynamic = current_equity * (
                remaining_multiple ** (elapsed / remaining_days)
            )
        rows.append({"date": current_date, "Original": original, "Dynamic": dynamic})
    return pd.DataFrame(rows)


def render_create_plan(
    *,
    current_reporting_equity: float,
    default_horizon_months: int = 24,
) -> None:
    st.subheader("Buat target")
    st.caption(
        "Start equity akan memakai equity Binance saat tombol Start Plan ditekan. "
        "Target dan horizon bisa diubah kapan saja dengan Reset Plan."
    )

    target = st.number_input(
        "Target Equity (IDR)",
        min_value=1_000_000.0,
        value=10_000_000_000.0,
        step=10_000_000.0,
        format="%.0f",
    )
    horizon = st.number_input(
        "Horizon (bulan)",
        min_value=1,
        max_value=240,
        value=default_horizon_months,
        step=1,
    )
    preview_date = add_months(date.today(), int(horizon))

    c1, c2, c3 = st.columns(3)
    c1.metric("Start Equity", money(current_reporting_equity, "IDR"))
    c2.metric("Target", money(target, "IDR"))
    c3.metric("Target Date", preview_date.strftime("%d %b %Y"))

    if st.button("Start Plan", type="primary", use_container_width=True):
        goal = Goal(
            start_equity=current_reporting_equity,
            target_equity=float(target),
            start_date=date.today(),
            target_date=preview_date,
            reporting_currency="IDR",
        )
        save_plan_to_url(goal)
        st.rerun()


def main() -> None:
    st.set_page_config(
        page_title="Compound Target Control",
        page_icon="📈",
        layout="wide",
        initial_sidebar_state="collapsed",
    )
    cfg = load_settings()

    st.title("Compound Target Control")
    st.caption(
        "Live Binance equity + compound target + adaptive risk + position sizing. "
        "Tidak membuat prediksi arah market."
    )

    with st.sidebar:
        st.header("Connection")
        usdt_to_idr = st.number_input(
            "USDT → IDR",
            min_value=1.0,
            value=float(cfg.currency["usdt_to_idr"]),
            step=100.0,
        )
        st.caption("FX manual supaya perubahan kurs tidak disalahartikan sebagai trading PnL.")

    try:
        with st.spinner("Membaca Binance Futures..."):
            trading_equity, available_balance, unrealized_pnl = read_binance_equity()
    except BinanceApiError as exc:
        st.error(str(exc))
        st.info(
            "Di Streamlit Cloud, buka App settings → Secrets lalu isi "
            "BINANCE_API_KEY dan BINANCE_API_SECRET."
        )
        st.stop()
    except Exception as exc:
        st.error(f"Gagal membaca Binance: {exc}")
        st.stop()

    reporting_equity = trading_equity * usdt_to_idr
    goal = load_plan_from_url()

    status_bar = st.columns(3)
    status_bar[0].metric("Binance Futures Equity", f"{trading_equity:,.2f} USDT")
    status_bar[1].metric("Approx. IDR", money(reporting_equity, "IDR"))
    status_bar[2].metric("Available Balance", f"{available_balance:,.2f} USDT")
    st.caption(f"Unrealized PnL: {unrealized_pnl:,.2f} USDT · Data refreshed on page run")

    if goal is None:
        render_create_plan(current_reporting_equity=reporting_equity)
        st.stop()

    if goal.target_date <= date.today():
        st.warning("Target date sudah lewat. Reset plan untuk membuat horizon baru.")

    snapshot = build_goal_snapshot(goal, reporting_equity, date.today())

    tabs = st.tabs(["Mission Control", "Trade Planner", "Plan"])

    with tabs[0]:
        top = st.columns(4)
        top[0].metric("Current Equity", money(reporting_equity, "IDR"))
        top[1].metric("Final Target", money(goal.target_equity, "IDR"))
        top[2].metric("Progress", f"{snapshot.progress_pct:.3%}")
        top[3].metric("Days Remaining", f"{snapshot.days_remaining:,}")

        second = st.columns(4)
        second[0].metric("Target Today", money(snapshot.baseline_equity, "IDR"))
        second[1].metric("Schedule Variance", f"{snapshot.schedule_variance_pct:.2%}")
        second[2].metric("Required Monthly", f"{snapshot.current_monthly_return:.2%}")
        second[3].metric("Target Pressure", f"{snapshot.target_pressure:.2f}×")

        st.subheader("Trajectory")
        curve = build_curve(goal, reporting_equity, date.today())
        fig = go.Figure()
        fig.add_trace(
            go.Scatter(
                x=curve["date"],
                y=curve["Original"],
                mode="lines",
                name="Original baseline",
            )
        )
        fig.add_trace(
            go.Scatter(
                x=curve["date"],
                y=curve["Dynamic"],
                mode="lines",
                name="Dynamic required",
                line={"dash": "dash"},
            )
        )
        fig.add_trace(
            go.Scatter(
                x=[date.today()],
                y=[reporting_equity],
                mode="markers",
                name="Actual",
                marker={"size": 12},
            )
        )
        fig.update_layout(
            height=390,
            yaxis_title="IDR",
            margin=dict(l=10, r=10, t=20, b=10),
            legend_orientation="h",
        )
        st.plotly_chart(fig, use_container_width=True)

        st.info(
            "Required return adalah trajectory untuk sisa horizon, bukan target PnL harian. "
            "Hari tanpa call tidak dianggap gagal."
        )

    with tabs[1]:
        st.subheader("Trade Planner")
        st.caption("Masukkan setup signal saat nanti mulai mengikuti signal secara manual.")

        col_a, col_b = st.columns(2)
        with col_a:
            symbol = st.text_input("Symbol", "BTCUSDT").upper()
            side = st.selectbox("Side", ["LONG", "SHORT"])
            entry = st.number_input("Entry", min_value=0.000001, value=100000.0)
            stop = st.number_input("Stop Loss", min_value=0.000001, value=98000.0)
            leverage = st.number_input("Leverage", min_value=1.0, max_value=125.0, value=5.0)
        with col_b:
            drawdown = st.slider("Current Drawdown", 0.0, 30.0, 0.0, 0.5) / 100
            open_risk = st.slider("Current Open Risk", 0.0, 3.0, 0.0, 0.1) / 100
            regime = st.selectbox(
                "Volatility condition",
                [item.value for item in VolatilityRegime],
                index=1,
            )

        service = PlanningService(
            risk_controller=RiskController(cfg.risk),
            execution_config=cfg.execution,
        )
        result = service.plan_trade(
            goal=goal,
            reporting_equity=reporting_equity,
            trading_equity=trading_equity,
            as_of=date.today(),
            drawdown_pct=drawdown,
            volatility_regime=VolatilityRegime(regime),
            open_risk_pct=open_risk,
            setup=TradeSetup(
                symbol=symbol,
                side=side,
                entry=entry,
                stop_loss=stop,
                leverage=leverage,
            ),
        )

        size = result.position
        risk = result.risk
        rows = st.columns(4)
        rows[0].metric("Effective R", f"{risk.effective_risk_pct:.3%}")
        rows[1].metric("Risk Budget", f"{size.risk_budget:,.2f} USDT")
        rows[2].metric("Recommended Notional", f"{size.recommended_notional:,.2f} USDT")
        rows[3].metric("Required Margin", f"{size.required_margin:,.2f} USDT")

        rows2 = st.columns(3)
        rows2[0].metric("Stop Distance", f"{size.stop_distance_pct:.2%}")
        rows2[1].metric("Est. loss at SL", f"{size.estimated_loss_at_stop:,.2f} USDT")
        rows2[2].metric("Actual Account Risk", f"{size.account_risk_pct:.3%}")

        with st.expander("Risk breakdown"):
            st.json(
                {
                    "base_risk_pct": risk.base_risk_pct,
                    "target_multiplier": risk.target_multiplier,
                    "drawdown_multiplier": risk.drawdown_multiplier,
                    "volatility_multiplier": risk.volatility_multiplier,
                    "equity_multiplier": risk.equity_multiplier,
                    "preservation_mode": risk.preservation_mode,
                    "open_risk_cap": risk.capped_by_open_risk,
                }
            )

    with tabs[2]:
        st.subheader("Current Plan")
        plan_cols = st.columns(4)
        plan_cols[0].metric("Start Equity", money(goal.start_equity, "IDR"))
        plan_cols[1].metric("Start Date", goal.start_date.strftime("%d %b %Y"))
        plan_cols[2].metric("Target", money(goal.target_equity, "IDR"))
        plan_cols[3].metric("Target Date", goal.target_date.strftime("%d %b %Y"))

        st.caption(
            "Plan tersimpan di URL non-sensitif agar tetap pulih setelah app sleep/restart. "
            "Bookmark link aplikasi setelah membuat plan."
        )

        if st.button("Reset Plan", type="secondary"):
            clear_plan_from_url()
            st.rerun()


if __name__ == "__main__":
    main()
