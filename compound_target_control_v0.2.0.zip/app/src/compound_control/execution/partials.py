from __future__ import annotations

from collections.abc import Iterable

from compound_control.domain.models import PartialExit, PartialPlanResult


def calculate_partial_plan(
    *,
    initial_risk: float,
    exits: Iterable[PartialExit],
    trailing_r_multiple: float | None,
    estimated_cost: float = 0.0,
) -> PartialPlanResult:
    if initial_risk <= 0:
        raise ValueError("initial_risk must be positive")

    exit_list = list(exits)
    total_fraction = sum(item.fraction for item in exit_list)
    if not 0.999999 <= total_fraction <= 1.000001:
        raise ValueError("partial exit fractions must sum to 1.0")

    gross_r = 0.0
    for item in exit_list:
        if item.fraction < 0:
            raise ValueError("partial exit fractions cannot be negative")
        multiple = item.r_multiple
        if multiple is None:
            if trailing_r_multiple is None:
                continue
            multiple = trailing_r_multiple
        gross_r += item.fraction * multiple

    gross_pnl = gross_r * initial_risk
    net_pnl = gross_pnl - estimated_cost
    return PartialPlanResult(
        gross_r=gross_r,
        net_r=net_pnl / initial_risk,
        gross_pnl=gross_pnl,
        net_pnl=net_pnl,
        estimated_cost=estimated_cost,
    )
