from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Sequence


@dataclass(frozen=True)
class PerformanceMetrics:
    trades: int
    win_rate: float
    average_winner_r: float
    average_loser_r: float
    expectancy_r: float
    profit_factor: float
    max_drawdown_r: float
    consecutive_losses: int


def _max_drawdown_from_r(results: Sequence[float]) -> float:
    equity = 0.0
    peak = 0.0
    max_dd = 0.0
    for value in results:
        equity += value
        peak = max(peak, equity)
        max_dd = max(max_dd, peak - equity)
    return max_dd


def _max_consecutive_losses(results: Sequence[float]) -> int:
    current = 0
    maximum = 0
    for value in results:
        if value < 0:
            current += 1
            maximum = max(maximum, current)
        else:
            current = 0
    return maximum


def calculate_performance(net_r_results: Sequence[float]) -> PerformanceMetrics:
    results = list(net_r_results)
    if not results:
        return PerformanceMetrics(0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0)

    winners = [r for r in results if r > 0]
    losers = [r for r in results if r < 0]
    gross_profit = sum(winners)
    gross_loss = abs(sum(losers))

    return PerformanceMetrics(
        trades=len(results),
        win_rate=len(winners) / len(results),
        average_winner_r=sum(winners) / len(winners) if winners else 0.0,
        average_loser_r=sum(losers) / len(losers) if losers else 0.0,
        expectancy_r=sum(results) / len(results),
        profit_factor=gross_profit / gross_loss if gross_loss > 0 else float("inf"),
        max_drawdown_r=_max_drawdown_from_r(results),
        consecutive_losses=_max_consecutive_losses(results),
    )
